<?php
return array("models\\Inscription"=>"default");
