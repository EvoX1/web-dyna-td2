<?php
return array("name"=>"web-dyna-td2","remoteUrl"=>"https://github.com/EvoX1/web-dyna-td2","baseFolder"=>"C:\\xampp\\htdocs\\web-dyna-td2","user"=>"EvoX1","password"=>"No_Gold12No_Carry");
