<?php

return array(
  '#namespace' => 'controllers',
  '#uses' => array (
  'UbiquityMyAdminBaseController' => 'Ubiquity\\controllers\\admin\\UbiquityMyAdminBaseController',
),
  '#traitMethodOverrides' => array (
  'controllers\\Admin' => 
  array (
  ),
),
);

